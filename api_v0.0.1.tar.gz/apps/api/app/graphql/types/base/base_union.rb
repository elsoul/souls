module Types
  class BaseUnion < GraphQL::Schema::Union
  end
end
