module Types
  class ArticleCategoryEdge < Types::BaseEdge
    node_type(Types::ArticleCategoryType)
  end
end
