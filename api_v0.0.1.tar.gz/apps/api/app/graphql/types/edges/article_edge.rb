module Types
  class ArticleEdge < Types::BaseEdge
    node_type(Types::ArticleType)
  end
end
