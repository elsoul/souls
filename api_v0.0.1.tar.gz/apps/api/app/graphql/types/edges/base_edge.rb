module Types
  class BaseEdge < GraphQL::Types::Relay::BaseEdge
  end
end
