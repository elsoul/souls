module Types
  class UserEdge < Types::BaseEdge
    node_type(Types::UserType)
  end
end
