class Types::ArticleConnection < Types::BaseConnection
  edge_type(Types::ArticleEdge)
end
