class Types::ArticleCategoryConnection < Types::BaseConnection
  edge_type(Types::ArticleCategoryEdge)
end
