class Types::UserConnection < Types::BaseConnection
  edge_type(Types::UserEdge)
end
