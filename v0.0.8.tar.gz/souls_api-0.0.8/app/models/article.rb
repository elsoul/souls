class Article < ActiveRecord::Base
  ## Relations
  belongs_to :user
  
end
