class ArticleSeries < ApplicationRecord
end
