class ApplicationController < Souls::Blog::Service
  include ArticleMethod, HelloMethod
end
